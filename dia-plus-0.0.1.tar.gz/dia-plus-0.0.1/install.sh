#!/bin/sh
#
# Author: atyu30 <iopenbsd@gmail.com>
#
# Last modified: 2015-01-15 15:24
#
# Filename: install.sh
#
# Description: 
#
DIAHOME=~/.dia

if [ ! -d ${DIAHOME} ];then
    mkdir ${DIAHOME}
    mkdir -p ${DIAHOME}/shapes
    mkdir -p ${DIAHOME}/sheets
fi

cp -R shapes/* ${DIAHOME}/shapes/
cp -R sheets/* ${DIAHOME}/sheets/
